package com.smeportal.proexpservice.dto;


import lombok.Data;

@Data
public class DisciplineDTO {
    private Long id;
    private String name;

}